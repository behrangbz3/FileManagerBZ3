package com.amaze.filemanager;

public class ads {
    public static int adShow = 0;
    public static boolean show = true;
    public static boolean show_tapsell = true;
    public static boolean show_admob = false;

    //***********************
    public static int adStatus = 0;
    public static String adSubjectText = "";
    public static String adDescriptionText = "";
    public static String adButtonText = "";
    public static String adActionType = "";
    public static String adIconLink_480 = "";
    public static String adIconLink_720 = "";
    public static String adIconLink_1080 = "";
    public static String adButtonIconLink_1080 = "";
    public static String adButtonIconLink_720 = "";
    public static String adButtonIconLink_480 = "";
    public static String adActionPackage = "";
    public static String adButtonTextColor = "";
    public static String adSubjectTextColor = "";
    public static String getAdDescriptionTextColor = "";
    public static String adActionLink = "";
    public static String adLayoutBackgroundColor = "";
    public static int bannerStatus = 0;
    public static int interstitialRate = 3;
    public static int buttonAnimation = 1;
    public static int buttonAnimationDuration = 1000;
    public static String bannerType = "";

    //admob
    public static int admobInterStitialStatus = 0;
    public static String app_id = "";
    public static String banner_id = "";
    public static String interstitial_id = "";
    public static int init_admob = 0;

    //*************************************************
    public static int width = 1080;


}
