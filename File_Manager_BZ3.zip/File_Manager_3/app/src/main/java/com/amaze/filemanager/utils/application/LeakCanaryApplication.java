package com.amaze.filemanager.utils.application;

import android.support.multidex.MultiDexApplication;

import co.ronash.pushe.Pushe;
import me.cheshmak.android.sdk.core.Cheshmak;

/**
 * @author Emmanuel
 *         on 28/8/2017, at 18:12.
 */

public class LeakCanaryApplication extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        /*
        if (LeakCanary.isInAnalyzerProcess(this)) {
            // This process is dedicated to LeakCanary for heap analysis.
            // You should not init your app in this process.
            return;
        }
        LeakCanary.install(this);*/
        //Cheshmak.with(getApplicationContext());
        //Cheshmak.initTracker("w/mbHYm9RWQO0abWizCJKA==");
        //Pushe.initialize(this,true);
    }

}