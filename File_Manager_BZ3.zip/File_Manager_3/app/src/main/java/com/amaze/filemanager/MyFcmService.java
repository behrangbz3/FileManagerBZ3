package com.amaze.filemanager;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import co.ronash.pushe.Pushe;
import me.cheshmak.android.sdk.core.push.CheshmakFirebaseMessagingService;

public class MyFcmService extends FirebaseMessagingService{
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if (Pushe.getFcmHandler(this).onMessageReceived(remoteMessage)) {
            // Message belongs to Pushe, no further action needed
            return;
        }

        // Message does not belong to Pushe, process message...
        CheshmakFirebaseMessagingService Cheshmak = new CheshmakFirebaseMessagingService();
        if(Cheshmak.isCheshmakMessage(remoteMessage)) Cheshmak.onMessageReceived(remoteMessage);
    }

    @Override
    public void onNewToken(String s) {
        Pushe.getFcmHandler(this).onNewToken(s);
    }

    @Override
    public void onMessageSent(String s) {
        Pushe.getFcmHandler(this).onMessageSent(s);
    }

    @Override
    public void onSendError(String s, Exception e) {
        Pushe.getFcmHandler(this).onSendError(s, e);
    }

    @Override
    public void onDeletedMessages() {
        Pushe.getFcmHandler(this).onDeletedMessages();
    }
}
